class LogResult(object):
    traces = {}
    num_fulfillments_in_log = None
    num_violations_in_log = None
    num_pendings_in_log = None
    num_activations_in_log = None
    num_traces_satisfied_in_log = None

    '''def __init__(self, traces, num_fulfillments_in_log, num_violations_in_log, num_pendings_in_log, num_activations_in_log, num_traces_satisfied_in_log):
        self.traces = traces
        self.num_fulfillments_in_log = num_fulfillments_in_log
        self.num_violations_in_log = num_violations_in_log
        self.num_pendings_in_log = num_pendings_in_log
        self.num_activations_in_log = num_activations_in_log
        self.num_traces_satisfied_in_log = num_traces_satisfied_in_log'''
